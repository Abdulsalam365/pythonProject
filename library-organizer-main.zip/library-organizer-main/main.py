# Teammitglieder:
#yazan.shreteh@stud.th-deg.de
#rafi.abdin@stud.th-deg.de
#mirand.gashi@stud.th-deg.de
#abdulsalam.alhammoud@stud.th-deg.de
from gui.app import run_gui

# Funktion für Parallel-Test importieren
from logic.parallel_logic import starte_parallel

if __name__ == "__main__":
    print("1 - GUI starten")
    print("2 - Parallel-Beispiel starten")
    wahl = input("Bitte wähle eine Option (1 oder 2): ")

    if wahl == "1":
        run_gui()
    elif wahl == "2":
        starte_parallel()
    else:
        print("Ungültige Auswahl.")