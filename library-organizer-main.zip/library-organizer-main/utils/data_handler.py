import json

# Bibliothek aus JSON-Datei laden
def load_library(file_path):
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        print("Datei nicht gefunden. Leere Bibliothek wird geladen.")
        return []
    except json.JSONDecodeError:
        print("Fehler beim Lesen der JSON-Datei.")
        return []

# Bibliothek in JSON-Datei speichern
def save_library(file_path, books):
    try:
        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(books, f, indent=4, ensure_ascii=False)
        print("Bibliothek wurde erfolgreich gespeichert.")
    except Exception as e:
        print("Fehler beim Speichern:", e)
