#  Library Organizer

Ein einfaches Python-Projekt zur Verwaltung einer digitalen Bibliothek mit GUI und paralleler Verarbeitung.

---

##  Projektübersicht

Das Programm ermöglicht:
-  Hinzufügen, Löschen und Suchen von Büchern
-  Anzeige aller gespeicherten Bücher
-  Parallele Generierung von 1 Million zufälligen Büchern

---

## > Ausführung

```bash
python main.py

