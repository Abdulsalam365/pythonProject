import tkinter as tk
from utils.data_handler import load_library, save_library
from logic.book_operations import add_book, delete_book, search_books
from logic.parallel_logic import starte_parallel
import json

# GUI starten
def run_gui():
    file_path = "data/library.json"
    books = load_library(file_path)

    # Funktion: Bücher anzeigen
    def show_books():
        output.delete("1.0", tk.END)
        for book in books:
            output.insert(tk.END, f"{book['title']} - {book['author']} ({book['year']})\n")

    # Funktion: Parallele Bücher aus anderer Datei anzeigen
    def show_parallel_books():
        output.delete("1.0", tk.END)
        try:
            with open("data/library_parallel.json", "r", encoding="utf-8") as f:
                parallel_books = json.load(f)
                for book in parallel_books:
                    output.insert(tk.END, f"{book['title']} - {book['author']} ({book['year']})\n")
        except FileNotFoundError:
            output.insert(tk.END, "Datei 'library_parallel.json' wurde nicht gefunden.\n")

    # Funktion: Parallele Bücher erzeugen
    def run_parallel():
        starte_parallel()

    # Funktion: Buch hinzufügen
    def add():
        title = title_entry.get()
        author = author_entry.get()
        year = year_entry.get()
        if title and author and year:
            try:
                year = int(year)
                add_book(books, title, author, year)
                save_library(file_path, books)
                show_books()
            except ValueError:
                output.insert(tk.END, "Jahr muss eine Zahl sein.\n")

    # Funktion: Buch löschen
    def delete():
        title = title_entry.get()
        if title:
            updated_books = delete_book(books, title)
            save_library(file_path, updated_books)
            books.clear()
            books.extend(updated_books)
            show_books()

    # Funktion: Nach Büchern suchen
    def search():
        query = search_entry.get()
        results = search_books(books, query)
        output.delete("1.0", tk.END)
        if results:
            for book in results:
                output.insert(tk.END, f"{book['title']} - {book['author']} ({book['year']})\n")
        else:
            output.insert(tk.END, "Kein Buch gefunden.\n")

    # Fenster aufbauen
    window = tk.Tk()
    window.title("Meine Bibliothek")

    # Eingabefelder
    tk.Label(window, text="Titel").pack()
    title_entry = tk.Entry(window)
    title_entry.pack()

    tk.Label(window, text="Autor").pack()
    author_entry = tk.Entry(window)
    author_entry.pack()

    tk.Label(window, text="Jahr").pack()
    year_entry = tk.Entry(window)
    year_entry.pack()

    # Suchfeld
    tk.Label(window, text="Suchbegriff (Titel)").pack()
    search_entry = tk.Entry(window)
    search_entry.pack()

    # Buttons
    tk.Button(window, text="Buch hinzufügen", command=add).pack()
    tk.Button(window, text="Buch löschen", command=delete).pack()
    tk.Button(window, text="Alle Bücher anzeigen", command=show_books).pack()
    tk.Button(window, text="Suchen", command=search).pack()
    tk.Button(window, text="Parallele Bücher anzeigen", command=show_parallel_books).pack()
    tk.Button(window, text="Parallele Bücher erzeugen", command=run_parallel).pack()

    # Text-Ausgabe
    output = tk.Text(window, height=15)
    output.pack()

    show_books()
    window.mainloop()

