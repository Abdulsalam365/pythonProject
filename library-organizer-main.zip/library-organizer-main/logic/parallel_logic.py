# parallel_logic.py
# Autor: Abdulsalam Alhammoud
# Beschreibung: Erzeugt 1 Million Bücher parallel mit zufälligen Daten

import json
import multiprocessing
import time
import random
import string

# Funktion zur zufälligen Erstellung eines Buchtitels
def zufalls_string(length=10):
    return ''.join(random.choices(string.ascii_letters + string.digits, k=length))

# Funktion, die Bücher erzeugt
def generiere_buecher(start, ende, rueckgabe_liste):
    buecher = []
    for i in range(start, ende):
        buch = {
            "title": f"{zufalls_string(8)}",
            "author": f"{zufalls_string(6)}",
            "year": random.randint(1950, 2025)
        }
        buecher.append(buch)
    rueckgabe_liste += buecher

# Startet die parallele Verarbeitung und speichert alle Bücher in JSON
def starte_parallel():
    print("Starte parallele Erzeugung von 1 Million Büchern...")
    startzeit = time.time()

    gesamt = 1_000_000
    prozessanzahl = 4
    schritte = gesamt // prozessanzahl

    manager = multiprocessing.Manager()
    rueckgabe_liste = manager.list()
    prozesse = []

    for i in range(prozessanzahl):
        start = i * schritte
        ende = gesamt if i == prozessanzahl - 1 else (i + 1) * schritte
        p = multiprocessing.Process(target=generiere_buecher, args=(start, ende, rueckgabe_liste))
        prozesse.append(p)
        p.start()

    for p in prozesse:
        p.join()

    with open("data/library_parallel.json", "w", encoding="utf-8") as f:
        json.dump(list(rueckgabe_liste), f, indent=4, ensure_ascii=False)

    dauer = time.time() - startzeit
    print(f"Fertig! Dauer: {dauer:.2f} Sekunden. Datei: 'library_parallel.json'")


