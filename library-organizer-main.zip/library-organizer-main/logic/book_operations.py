# Buch zur Bibliothek hinzufügen
def add_book(books, title, author, year):
    """
    Fügt ein neues Buch zur Liste hinzu.
    """
    books.append({"title": title, "author": author, "year": year})
    return books

# Buch aus der Bibliothek löschen
def delete_book(books, title):
    """
    Entfernt ein Buch anhand des Titels.
    """
    return [book for book in books if book["title"].lower() != title.lower()]

# Nach Büchern anhand des Titels suchen
def search_books(books, query):
    """
    Sucht nach Büchern, deren Titel den Suchbegriff enthalten.
    """
    return [book for book in books if query.lower() in book["title"].lower()]
